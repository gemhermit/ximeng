
import React from 'react';
import TiltCard from './TiltCard';

const modules = [
  { 
      id: 'module-1', 
      icon: 'fa-industry', 
      color: 'blue', 
      title: '工业制造 4.0', 
      desc: '智能工厂的数字化神经系统。', 
      detail: '深度融合 OT 运营技术与 IT 信息技术。通过 IoT 传感器全域连接，实现产线毫秒级实时监控、设备故障 AI 预测性维护以及柔性生产调度，助力企业产能提升 30% 以上。' 
  },
  { 
      id: 'module-2', 
      icon: 'fa-graduation-cap', 
      color: 'green', 
      title: '未来教育科技', 
      desc: '个性化 AI 辅导与沉浸式课堂。', 
      detail: '构建 K12 知识图谱，利用 NLP 技术为每位学生定制专属学习路径。结合 XR 扩展现实技术，将抽象概念具象化，打造身临其境的全息互动教学体验。' 
  },
  { 
      id: 'module-3', 
      icon: 'fa-landmark', 
      color: 'pink', 
      title: '元宇宙文旅', 
      desc: '虚实共生的数字时空新体验。', 
      detail: '基于 UE5 引擎的高精度数字孪生复刻技术，将历史古迹与自然风光搬上云端。通过 AR 空间计算，为游客提供穿越时空的导览与互动，重塑文旅商业模式。' 
  },
  { 
      id: 'module-4', 
      icon: 'fa-cloud', 
      color: 'cyan', 
      title: '云原生引擎', 
      desc: '弹性、安全、高可用的算力底座。', 
      detail: '自研 Serverless 容器架构，支持秒级弹性扩容以应对流量洪峰。提供多云纳管、云边协同调度及金融级安全防护，为企业核心业务提供坚如磐石的数字地基。' 
  },
  { 
      id: 'module-5', 
      icon: 'fa-bullseye', 
      color: 'purple', 
      title: '全域智能营销', 
      desc: '数据驱动的精准流量增长引擎。', 
      detail: '打通 CDP 客户数据平台，构建 360 度动态用户画像。利用 AIGC 自动化生成千人千面的营销素材，在正确的时间通过正确的渠道触达用户，实现 ROI 最大化。' 
  },
  { 
      id: 'module-6', 
      icon: 'fa-microchip', 
      color: 'orange', 
      title: '端侧 AI 硬件', 
      desc: '软硬一体的边缘计算解决方案。', 
      detail: '提供基于 RISC-V 架构的专用 AI 芯片定制与嵌入式开发。针对视觉识别、语音交互等场景进行算法加速，以超低功耗赋能机器人、智能安防等端侧设备。' 
  },
];

const Modules: React.FC = () => {
  return (
    <section id="modules" className="py-24 md:py-32 relative bg-slate-950/50">
      <div className="container mx-auto px-6">
        <div className="mb-16 md:mb-20 text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">全栈解决方案</h2>
          <p className="text-gray-400 text-sm md:text-base max-w-2xl mx-auto">
            六大核心引擎，驱动企业全场景数字化转型。我们不仅提供技术，更提供面向未来的生存能力。
          </p>
        </div>
        
        {/* Adjusted Grid: grid-cols-1 on mobile (important fix), grid-cols-2 on tablet, grid-cols-3 on desktop */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {modules.map((mod) => (
            <TiltCard key={mod.id} className="h-auto min-h-[380px] md:h-[420px]">
              <div className={`relative w-full h-full rounded-2xl overflow-hidden border border-white/10 bg-white/5 backdrop-blur-sm`}>
                {/* Gradient Hover Background */}
                <div className={`absolute inset-0 bg-gradient-to-br from-${mod.color}-900 via-${mod.color}-800 to-${mod.color}-600 opacity-0 group-hover:opacity-90 transition-opacity duration-500 ease-out z-0`}></div>
                
                <div className="relative z-10 p-6 md:p-8 h-full flex flex-col transition-transform duration-500 group-hover:-translate-y-2">
                  <div className="mb-6">
                    <div className={`w-14 h-14 rounded-xl bg-white/10 flex items-center justify-center text-${mod.color}-400 group-hover:bg-white group-hover:text-${mod.color}-600 transition-colors shadow-lg`}>
                      <i className={`fas ${mod.icon} text-2xl`}></i>
                    </div>
                  </div>
                  
                  <h3 className="text-2xl font-bold mb-3 text-white">{mod.title}</h3>
                  <p className={`text-gray-400 text-sm group-hover:text-${mod.color}-100 transition-colors mb-4`}>{mod.desc}</p>
                  
                  <div className="mt-auto pt-4 border-t border-white/10 group-hover:border-white/20">
                    <p className={`text-sm text-${mod.color}-50/80 leading-relaxed mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500 absolute bottom-12 left-6 right-6 md:static md:opacity-100 md:block hidden md:group-hover:text-white`}>
                        {mod.detail}
                    </p>
                    {/* Mobile Only Summary (always visible) */}
                    <p className="text-sm text-gray-500 leading-relaxed mb-4 md:hidden block group-hover:text-white/90">
                        {mod.detail}
                    </p>

                    <div className="flex items-center text-white font-bold text-sm tracking-wide mt-2">
                      了解更多 <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                    </div>
                  </div>
                </div>
              </div>
            </TiltCard>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Modules;
