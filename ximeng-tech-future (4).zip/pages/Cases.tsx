
import React, { useLayoutEffect, useRef } from 'react';
import PageHeader from '../components/PageHeader';
import TiltCard from '../components/TiltCard';

const gsap = (window as any).gsap;

const cases = [
    { title: '城市大脑 v3.0', cat: 'SMART CITY', img: '/images/case-city.jpg', stats: '拥堵率 -25%' },
    { title: '柔性生产协作臂', cat: 'INDUSTRY 4.0', img: '/images/case-arm.jpg', stats: '效率 +40%' },
    { title: 'AI 蛋白质折叠', cat: 'BIOTECH', img: '/images/case-bio.jpg', stats: '研发周期 -60%' },
    { title: '零碳液冷数据中心', cat: 'GREEN TECH', img: '/images/case-data.jpg', stats: 'PUE 1.09' },
    { title: '“曦光” NPU 芯片', cat: 'HARDWARE', img: '/images/case-chip.jpg', stats: '20 TOPS/W' },
    { title: '元宇宙历史课堂', cat: 'EDUCATION', img: '/images/case-edu.jpg', stats: '互动率 +80%' },
    { title: '无人驾驶物流车', cat: 'LOGISTICS', img: '/images/case-car.jpg', stats: '成本 -45%' },
    { title: '深海探测机器人', cat: 'OCEAN', img: '/images/case-ocean.jpg', stats: '深度 10000m' },
];

const Cases: React.FC = () => {
    const containerRef = useRef(null);

    useLayoutEffect(() => {
        let ctx = gsap.context(() => {
            gsap.from(".case-card", {
                y: 50,
                opacity: 0,
                duration: 0.8,
                stagger: 0.1,
                ease: "power3.out",
                delay: 0.2
            });
        }, containerRef);
        return () => ctx.revert();
    }, []);

    return (
        <div ref={containerRef} className="min-h-screen bg-slate-950">
            <PageHeader title="创新案例实验室" subtitle="Innovation Lab" gradient="from-purple-400 via-pink-400 to-red-400" />
            
            <div className="container mx-auto px-6 py-20">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {cases.map((item, idx) => (
                        <div key={idx} className="case-card">
                            <TiltCard className="h-[350px]">
                                <div className="group relative w-full h-full rounded-2xl overflow-hidden border border-white/10 bg-slate-900 cursor-default">
                                    <img src={item.img} alt={item.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-70 group-hover:opacity-100" />
                                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                                    
                                    <div className="absolute top-4 right-4 bg-white/10 backdrop-blur-md px-3 py-1 rounded text-xs font-mono border border-white/10">
                                        {item.stats}
                                    </div>

                                    <div className="absolute bottom-0 left-0 p-6 w-full">
                                        <div className="text-xs text-blue-400 font-bold tracking-widest mb-2">{item.cat}</div>
                                        <h3 className="text-2xl font-bold text-white mb-2">{item.title}</h3>
                                    </div>
                                </div>
                            </TiltCard>
                        </div>
                    ))}
                </div>
            </div>
            
            <div className="h-20"></div>
        </div>
    );
};

export default Cases;
