
import React, { useLayoutEffect, useRef } from 'react';
import PageHeader from '../components/PageHeader';
import TiltCard from '../components/TiltCard';

const gsap = (window as any).gsap;

const solutionsData = [
    {
        id: 'industrial',
        title: '工业制造 4.0',
        subtitle: 'Industrial Intelligence',
        desc: '将传统产线转化为具有自我感知、自我决策能力的智能体。',
        features: ['OT/IT 深度融合', '毫秒级预测性维护', '数字孪生工厂', '柔性生产调度'],
        icon: 'fa-industry',
        color: 'blue',
        image: '/images/solution-industrial.jpg'
    },
    {
        id: 'education',
        title: '未来教育科技',
        subtitle: 'Future Education',
        desc: '打破物理教室的边界，让知识在三维空间中触手可及。',
        features: ['K12 知识图谱', '全息互动课堂', 'AI 个性化助教', '沉浸式实验'],
        icon: 'fa-graduation-cap',
        color: 'green',
        image: '/images/solution-education.jpg'
    },
    {
        id: 'culture',
        title: '元宇宙文旅',
        subtitle: 'Metaverse Tourism',
        desc: '在云端重建文明瑰宝，通过 AR/VR 创造穿越时空的旅行。',
        features: ['UE5 级高精建模', 'AR 实景导览', '虚拟数字人讲解', 'NFT 数字藏品'],
        icon: 'fa-landmark',
        color: 'pink',
        image: '/images/solution-culture.jpg'
    },
    {
        id: 'cloud',
        title: '云原生引擎',
        subtitle: 'Cloud Native Engine',
        desc: '为数字化世界提供源源不断的算力支持，安全、弹性、高效。',
        features: ['Serverless 架构', '多云纳管', '边缘计算协同', '金融级安全'],
        icon: 'fa-cloud',
        color: 'cyan',
        image: '/images/solution-cloud.jpg'
    },
    {
        id: 'marketing',
        title: '全域智能营销',
        subtitle: 'AI Marketing',
        desc: '用数据洞察人心，用 AIGC 创造内容，实现指数级增长。',
        features: ['CDP 客户数据平台', '自动化内容生成', '全渠道触点管理', 'ROI 实时分析'],
        icon: 'fa-bullseye',
        color: 'purple',
        image: '/images/solution-marketing.jpg'
    },
    {
        id: 'hardware',
        title: '端侧 AI 硬件',
        subtitle: 'Edge AI Hardware',
        desc: '极致能效比的定制芯片，让万物皆可智能。',
        features: ['RISC-V 架构定制', 'NPU 神经网络加速', '低功耗设计', '软硬一体交付'],
        icon: 'fa-microchip',
        color: 'orange',
        image: '/images/solution-hardware.jpg'
    }
];

const Solutions: React.FC = () => {
    const containerRef = useRef(null);

    useLayoutEffect(() => {
        let ctx = gsap.context(() => {
            gsap.from(".anim-item", {
                y: 50,
                opacity: 0,
                duration: 0.8,
                stagger: 0.1,
                ease: "power3.out",
                delay: 0.2
            });
        }, containerRef);
        return () => ctx.revert();
    }, []);

    return (
        <div ref={containerRef} className="min-h-screen bg-slate-950">
            <PageHeader title="全栈解决方案" subtitle="Solutions Matrix" />

            <div className="container mx-auto px-6 py-20">
                <div className="space-y-32">
                    {solutionsData.map((item, index) => (
                        <div key={item.id} id={item.id} className={`flex flex-col md:flex-row gap-12 md:gap-20 items-center anim-item ${index % 2 === 1 ? 'md:flex-row-reverse' : ''}`}>
                            
                            {/* Visual Side */}
                            <div className="w-full md:w-1/2">
                                <TiltCard className="h-[300px] md:h-[400px]">
                                    <div className="relative w-full h-full rounded-2xl overflow-hidden border border-white/10 group">
                                        <img src={item.image} alt={item.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                                        <div className={`absolute inset-0 bg-gradient-to-t from-${item.color}-900/80 to-transparent mix-blend-multiply`}></div>
                                        <div className="absolute top-4 left-4 p-3 bg-slate-950/50 backdrop-blur-md rounded-lg border border-white/10">
                                            <i className={`fas ${item.icon} text-2xl text-${item.color}-400`}></i>
                                        </div>
                                    </div>
                                </TiltCard>
                            </div>

                            {/* Content Side */}
                            <div className="w-full md:w-1/2 space-y-6">
                                <div className={`text-${item.color}-400 font-bold tracking-widest text-sm uppercase`}>{item.subtitle}</div>
                                <h2 className="text-3xl md:text-4xl font-bold text-white">{item.title}</h2>
                                <p className="text-gray-400 text-lg leading-relaxed">{item.desc}</p>
                                
                                <div className="grid grid-cols-2 gap-4 pt-4">
                                    {item.features.map((feature, i) => (
                                        <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-white/5 border border-white/5 transition-colors">
                                            <div className={`w-1.5 h-1.5 rounded-full bg-${item.color}-500 shadow-[0_0_8px_currentColor]`}></div>
                                            <span className="text-sm font-medium text-gray-200">{feature}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            
            <div className="h-20"></div>
        </div>
    );
};

export default Solutions;
