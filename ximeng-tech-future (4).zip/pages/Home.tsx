import React from 'react';
import Hero from '../components/Hero';
import Modules from '../components/Modules';
import Showcase from '../components/Showcase';
import Values from '../components/Values';
import Partners from '../components/Partners';
import Join from '../components/Join';

const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <Modules />
      <Showcase />
      <Values />
      <Partners />
      <Join />
    </>
  );
};

export default Home;